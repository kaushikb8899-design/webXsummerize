/**
 * ResearchBrief AI - Chrome Extension Background script
 * This script is provided as a premium, copy-pasteable asset to run the browser extension locally.
 * It manages active session states, intercepts completed tab loads silently, and stores visited contexts.
 */

let isTracking = false;

// Initialize state
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({
    isTracking: false,
    trackedUrls: []
  });
  console.log("ResearchBrief AI: Browser Extension Engine Activated.");
});

// Messages router
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "startTracking") {
    isTracking = true;
    chrome.storage.local.set({ isTracking: true, trackedUrls: [] }, () => {
      console.log("ResearchBrief AI: Auto-tracking tracking turned ON.");
      sendResponse({ status: "started", tracking: true });
    });
    return true; // Keep message channel open for async response
  } 
  
  else if (message.action === "stopTracking") {
    isTracking = false;
    chrome.storage.local.set({ isTracking: false }, () => {
      chrome.storage.local.get(["trackedUrls"], (result) => {
        console.log("ResearchBrief AI: Auto-tracking tracking turned OFF. Target count:", (result.trackedUrls || []).length);
        sendResponse({ status: "stopped", urls: result.trackedUrls || [] });
      });
    });
    return true;
  } 
  
  else if (message.action === "getStatus") {
    chrome.storage.local.get(["isTracking", "trackedUrls"], (result) => {
      sendResponse({
        isTracking: result.isTracking || false,
        urls: result.trackedUrls || []
      });
    });
    return true;
  }
});

// Listen to tabs update to capture visited locations securely
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (isTracking && changeInfo.status === "complete" && tab.url) {
    const url = tab.url;
    // Exclude special browser schemes
    if (url.startsWith("http://") || url.startsWith("https://")) {
      chrome.storage.local.get(["trackedUrls"], (result) => {
        let tracked = result.trackedUrls || [];
        
        // Ensure uniqueness
        if (!tracked.some(item => item.url === url)) {
          tracked.push({
            url: url,
            title: tab.title || url,
            timestamp: new Date().toISOString()
          });
          
          chrome.storage.local.set({ trackedUrls: tracked }, () => {
            console.log("ResearchBrief AI: Captured live browsing location:", url);
            // Broadcast captured tabs back to popup/app.js if active
            chrome.runtime.sendMessage({
              event: "urlCaptured",
              url: url,
              title: tab.title || url,
              count: tracked.length
            });
          });
        }
      });
    }
  }
});
